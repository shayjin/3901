# animations for graphics
def anime1
  40.times do 
    sleep 0.005
    print "*"
  end
  puts ""
end

def anime2
  puts "|                                      |"
end

