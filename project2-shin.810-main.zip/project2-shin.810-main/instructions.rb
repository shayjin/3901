def instructions
  puts 'inst'
end
