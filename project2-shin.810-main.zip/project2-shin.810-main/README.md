# project2-shin.810

### Game of Set

The Game of Set is a card game. The deck consists of 81 cards of 4 features: number, color, shape, and shading. 

A set is formed when 3 cards satisfy the requirements. For each 1 of the 4 features, 3 cards must have the same features or different features.

In other words, you must avoid having 2 cards showing 1 version of the feature and the remaining card showing a different version. 

The Game of Set can be executed by running ```ruby main.rb```. 

### Programmer:
Jay Shin (shin.810)

### Language Used: 
Ruby
