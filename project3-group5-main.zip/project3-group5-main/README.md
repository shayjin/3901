# project3-group5
- Members: Jay Shin, Robbie Rogers, Klejdi Vrekaj, Riley Gillman

# Program Description
- This program reads in data from 'https://cse.osu.edu/current-students/undergraduate/majors/bs-cse/bs-cse-curriculum' about The Ohio State University's Computer Science and Engineering (CSE) bachelors program.
- It will break down by catergory the amount of credit hours needed for a BS in CSE.

# Program Controls
- The program is ran by enterng ```ruby main.rb```.
- Once the program is ran it will prompt the user which category they would like to see.
- Simply enter the number next to the category you would like to see.
    - For example, entering '3' would display information on the Non-Computer Science Core Choices.
- To exit the program type any other character than a category choice.
